<?php

	$host = "localhost";
	$user = "maka";
	$pass = "Klasa1618";
	$db = "lisekkk";

?>
